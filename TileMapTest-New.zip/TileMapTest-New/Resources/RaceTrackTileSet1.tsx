<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="RaceTrackImages1" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="2809" columns="53">
 <image source="RaceTrackImages1.png" width="1758" height="1760"/>
</tileset>
